// src/services/agents-providers/AgentToolSafetyService.ts
import { randomUUID as randomUUID2 } from "node:crypto";

// src/services/agents-providers/agent-tool-safety-service/agentToolAdmission.ts
var maxProposalLength = 32768;
function parse(proposal) {
  if (typeof proposal !== "string" || proposal.length > maxProposalLength)
    return;
  try {
    return parseEnvelope(JSON.parse(proposal));
  } catch {
    return;
  }
}
function parseEnvelope(value) {
  if (!value || typeof value !== "object" || Array.isArray(value))
    return;
  if (!("tool" in value) || !("input" in value) || Object.keys(value).length !== 2)
    return;
  if (typeof value.tool !== "string" || !/^[a-z][a-z0-9_-]{0,63}$/.test(value.tool))
    return;
  return { tool: value.tool, input: value.input };
}
function allowsAgentTool(policy, admission) {
  return policy?.revision === admission.policy.revision && policy.specialty === admission.policy.specialty && policy.declaredTools.includes(admission.tool) && policy.grants.some(({ tool, resource }) => tool === admission.tool && resource === admission.prepared.resource);
}
function admitAgentTool(options, agentId, proposal) {
  const parsed = parse(proposal);
  if (!parsed)
    return "invalid-proposal";
  if (!Object.hasOwn(options.tools, parsed.tool))
    return "unknown-tool";
  const { action, prepare } = options.tools[parsed.tool];
  const policy = options.policy(agentId);
  if (!policy?.declaredTools.includes(parsed.tool))
    return "not-authorized";
  try {
    const prepared = prepare(parsed.input);
    if (!validPrepared(action, prepared))
      return "invalid-proposal";
    const admission = {
      agentId,
      tool: parsed.tool,
      action,
      prepared: { ...prepared, charge: prepared.charge },
      policy: { ...policy },
      proposal
    };
    return allowsAgentTool(policy, admission) ? admission : "not-authorized";
  } catch {
    return "invalid-proposal";
  }
}
function validPrepared(action, prepared) {
  return !!prepared?.resource && !!prepared.summary && validCharge(action, prepared.charge);
}
function validCharge(action, charge) {
  if (charge)
    return /^[A-Z][A-Z0-9]{1,15}$/.test(charge.currency) && Number.isSafeInteger(charge.maximum) && charge.maximum > 0;
  return action !== "payment";
}
async function agentToolContentDenial(options, admission) {
  const { action, prepared, policy } = admission;
  const required = action === "message" || action === "publish" || action === "external-output";
  if (!required && prepared.content === undefined)
    return;
  if (typeof prepared.content !== "string" || !options.checkContent)
    return "content-unavailable";
  try {
    if (await options.checkContent(prepared.content, { specialty: policy.specialty, action }) === true)
      return;
    return "content-rejected";
  } catch {
    return "content-unavailable";
  }
}

// src/services/agents-providers/agent-tool-safety-service/reserveAgentTool.ts
import { createHash, randomUUID } from "node:crypto";
var minuteMs = 60000;
var approvalTtlMs = 5 * minuteMs;
function requiresAgentToolApproval(action) {
  return action !== "file-read" && action !== "network-read";
}
function fingerprint(admission) {
  const { agentId, action, policy, prepared, proposal } = admission;
  const binding = [
    agentId,
    policy.revision,
    policy.specialty,
    action,
    prepared.resource,
    prepared.summary,
    prepared.content,
    prepared.charge?.currency,
    prepared.charge?.maximum,
    proposal
  ];
  return createHash("sha256").update(JSON.stringify(binding)).digest("hex");
}
function budgetDenial(journal, attempt, policy, charge) {
  const usage = journal.usage(attempt.agentId, attempt.at - minuteMs, charge?.currency);
  if (!Number.isSafeInteger(policy.maxCallsPerMinute) || usage.count >= policy.maxCallsPerMinute)
    return "rate-limit";
  if (!charge)
    return;
  return spendDenial(policy.budgets, charge, usage.spend);
}
function spendDenial(budgets, charge, spend) {
  const budget = Object.hasOwn(budgets ?? {}, charge.currency) ? budgets?.[charge.currency] : undefined;
  if (!budget || !Number.isSafeInteger(budget.perAction) || !Number.isSafeInteger(budget.lifetime))
    return "spend-limit";
  if (charge.maximum > budget.perAction || charge.maximum > budget.lifetime - spend)
    return "spend-limit";
  return;
}
function reserveAgentTool(journal, attempt, admission, approvalId) {
  const { action, policy, prepared } = admission;
  const { charge, summary } = prepared;
  const denial = budgetDenial(journal, attempt, policy, charge);
  if (denial)
    return { status: "denied", reason: denial };
  if (approvalId !== undefined && !validApproval(journal.pending(approvalId), attempt, admission))
    return { status: "denied", reason: "approval-invalid" };
  if (requiresAgentToolApproval(action) && approvalId === undefined) {
    const approval = {
      id: randomUUID(),
      agentId: attempt.agentId,
      expiresAt: attempt.at + approvalTtlMs,
      fingerprint: fingerprint(admission)
    };
    journal.append({ ...attempt, state: "held", approval });
    return {
      status: "held",
      review: { id: approval.id, expiresAt: approval.expiresAt, action, summary, charge }
    };
  }
  journal.append({ ...attempt, state: "reserved", approvalId, charge });
  return;
}
function validApproval(approval, attempt, admission) {
  return !!approval && approval.agentId === attempt.agentId && approval.expiresAt > attempt.at && approval.fingerprint === fingerprint(admission);
}

// src/services/agents-providers/AgentToolSafetyService.ts
class AgentToolSafetyService {
  options;
  constructor(options) {
    this.options = options;
  }
  submit(agentId, proposal) {
    return this.dispatch(agentId, proposal);
  }
  approve(agentId, approvalId, proposal) {
    return this.dispatch(agentId, proposal, approvalId ?? "");
  }
  now() {
    return this.options.now?.() ?? Date.now();
  }
  record(event) {
    this.options.journal.transaction((journal) => journal.append(event));
  }
  async dispatch(agentId, proposal, approvalId) {
    try {
      const attempt = { agentId, attemptId: randomUUID2(), at: this.now() };
      this.record({ ...attempt, state: "requested" });
      const admitted = this.admit(agentId, proposal);
      if (typeof admitted === "string")
        return this.deny(attempt, admitted);
      const toolAttempt = { ...attempt, tool: admitted.tool };
      const denial = await agentToolContentDenial(this.options, admitted);
      if (denial)
        return this.deny(toolAttempt, denial);
      return await this.dispatchAdmitted(toolAttempt, admitted, approvalId);
    } catch {
      return { status: "denied", reason: "journal-unavailable" };
    }
  }
  admit(agentId, proposal) {
    try {
      return admitAgentTool(this.options, agentId, proposal);
    } catch {
      return "not-authorized";
    }
  }
  deny(attempt, reason) {
    this.record({ ...attempt, at: this.now(), state: "denied", reason });
    return { status: "denied", reason };
  }
  async dispatchAdmitted(attempt, admitted, approvalId) {
    const decision = this.options.journal.transaction((journal) => {
      const current = this.currentPolicy(admitted);
      const event = { ...attempt, at: this.now() };
      const result = current ? reserveAgentTool(journal, event, { ...admitted, policy: current }, approvalId) : { status: "denied", reason: "not-authorized" };
      if (result?.status === "denied")
        journal.append({ ...event, state: "denied", reason: result.reason });
      return result;
    });
    return decision ?? this.execute(attempt, admitted);
  }
  currentPolicy(admitted) {
    try {
      const current = this.options.policy(admitted.agentId);
      return allowsAgentTool(current, admitted) ? current : undefined;
    } catch {
      return;
    }
  }
  async execute(attempt, admitted) {
    const assertCurrent = () => {
      if (!this.currentPolicy(admitted))
        throw new Error("Tool authorization changed.");
    };
    let decision;
    try {
      assertCurrent();
      decision = { status: "executed", output: await admitted.prepared.execute(assertCurrent) };
    } catch {
      decision = { status: "failed" };
    }
    try {
      const state = decision.status === "executed" ? "completed" : "failed";
      this.record({ ...attempt, at: this.now(), state });
      return decision;
    } catch {
      return { status: "failed" };
    }
  }
}
export {
  AgentToolSafetyService
};
