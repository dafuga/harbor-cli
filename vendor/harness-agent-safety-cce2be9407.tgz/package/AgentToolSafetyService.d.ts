import type { AgentToolDecision, AgentToolSafetyOptions } from './AgentToolSafetyService.types.js';
/** Dispatches model tool proposals within current host grants and durable human approvals. */
export declare class AgentToolSafetyService {
    private readonly options;
    constructor(options: AgentToolSafetyOptions);
    /** Submit an untrusted JSON proposal. Only the owner channel can call approve. */
    submit(agentId: string, proposal: string): Promise<AgentToolDecision>;
    /** Execute the exact action approved by the authenticated owner. */
    approve(agentId: string, approvalId: string, proposal: string): Promise<AgentToolDecision>;
    private now;
    private record;
    private dispatch;
    private admit;
    private deny;
    private dispatchAdmitted;
    private currentPolicy;
    private execute;
}
