import type { AgentToolDenial, AgentToolPolicy, AgentToolSafetyOptions } from '../AgentToolSafetyService.types.js';
import type { AgentToolAdmission } from './agentToolAdmission.types.js';
export declare function allowsAgentTool(policy: AgentToolPolicy | undefined, admission: AgentToolAdmission): policy is AgentToolPolicy;
export declare function admitAgentTool(options: AgentToolSafetyOptions, agentId: string, proposal: string): AgentToolAdmission | AgentToolDenial;
export declare function agentToolContentDenial(options: AgentToolSafetyOptions, admission: AgentToolAdmission): Promise<AgentToolDenial | undefined>;
