import type { AgentToolDecision, AgentToolEvent, AgentToolJournalTransaction } from '../AgentToolSafetyService.types.js';
import type { AgentToolAdmission } from './agentToolAdmission.types.js';
export declare function requiresAgentToolApproval(action: AgentToolAdmission['action']): boolean;
export declare function reserveAgentTool(journal: AgentToolJournalTransaction, attempt: Pick<AgentToolEvent, 'at' | 'agentId' | 'attemptId' | 'tool'>, admission: AgentToolAdmission, approvalId?: string): Exclude<AgentToolDecision, {
    status: 'executed' | 'failed';
}> | undefined;
